This directory contains a demo CA that we use for autotesting
QSslSocket w/friends. To restore the CA from scratch, unpack this
directory into /etc/ssl. - Andreas

